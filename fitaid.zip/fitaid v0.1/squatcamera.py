import cv2 as cv
import mediapipe as mp
import poseEstimationModule as pm
import numpy as np

cap = cv.VideoCapture(0)
detector = pm.poseEstimation()
dir = 0
count = 0


while True:
    isTrue, img = cap.read()
    img = cv.resize(img, (1000, 600))
    img = detector.findPose(img, False)
    lmlist = detector.getPosition(img)
    if len(lmlist) != 0:
        angle = detector.Squatangle(img, 16, 14, 12, 24, 26, 28)

        per = np.interp(angle, (245, 350), (0, 100))
        bar = np.interp(angle, (260, 350), (250, 100))
        # print(bar)
        if per == 100:
            if dir == 0:
                count += 0.5
                dir = 1
        if per == 0:
            if dir == 1:
                count += 0.5
                dir = 0

        cv.rectangle(img, (20, 100), (40, 250), (0, 0, 0), 1)
        cv.rectangle(img, (20, int(bar)), (40, 250), (255, 0, 0), cv.FILLED)
        cv.putText(img, f'{int(per)}%', (20, 80),
                   cv.FONT_HERSHEY_PLAIN, 1, (0, 0, 0), 1)
        cv.putText(img, "Count:", (5, 550),
                   cv.FONT_HERSHEY_PLAIN, 2, (255, 0, 0), 3)
        cv.putText(img, str(count), (115, 550),
                   cv.FONT_HERSHEY_PLAIN, 2, (255, 0, 0), 3)

    cv.imshow("video", img)
    if cv.waitKey(1) & 0xff == ord("a"):
        break
cap.release()
cv.destroyAllWindows()
