from tkinter import *
from tkinter import ttk
import datetime
import time


def register():
    name1 = name.get()
    height1 = height.get()
    gen1 = gender.get()
    weight1 = weight.get()
    age1 = age.get()
    if name1 == '' or height1 == '' or weight1 == '' or gen1 == '' or age1 == '':
        message.set("fill the empty field!!!")
    else:
        filename = names = open("C:/Users/Binit/Desktop/fitaid v0.1/name.txt", "w")
        filename.write(name1)
        fileheight = names = open("C:/Users/Binit/Desktop/fitaid v0.1/Height.txt", "w")
        fileheight.write(height1)
        filegender = names = open("C:/Users/Binit/Desktop/fitaid v0.1/gender.txt", "w")
        filegender.write(gen1)
        fileweight = names = open("C:/Users/Binit/Desktop/fitaid v0.1/weight.txt", "w")
        fileweight.write(weight1)
        fileage = names = open("C:/Users/Binit/Desktop/fitaid v0.1/age.txt", "w")
        fileage.write(age1)
        message.set("Stored successfully!")


def Registrationform():
    global reg_screen
    reg_screen = Tk()
    reg_screen.title("Registration Form")
    reg_screen.geometry("600x500")
    global message
    global name
    global height
    global weight
    global gender
    global age
    global body
    name = StringVar()
    height = StringVar()
    weight = StringVar()
    gender = StringVar()
    age = StringVar()
    body = StringVar()
    message = StringVar()
    Label(reg_screen, width="300", text="Please enter details below",
          bg="#3d6466", fg="black").pack()

    Label(reg_screen, text="Name * ").place(x=200, y=40)
    Entry(reg_screen, textvariable=name).place(x=270, y=42)

    Label(reg_screen, text="Height*(cm) ").place(x=200, y=80)
    Entry(reg_screen, textvariable=height).place(x=270, y=82)

    Label(reg_screen, text="Weigt*(Kg) ").place(x=200, y=120)
    Entry(reg_screen, textvariable=weight).place(x=270, y=122)

    Label(reg_screen, text="Gender *").place(x=200, y=160)
    Entry(reg_screen, textvariable=gender).place(x=270, y=162)

    Label(reg_screen, text="Age *").place(x=200, y=200)
    Entry(reg_screen, textvariable=age).place(x=270, y=202)

    Label(reg_screen, text="", textvariable=message).place(x=275, y=264)
    Button(reg_screen, text="Register", width=10, height=1,
           bg="#3d6466", command=register).place(x=280, y=300)
    reg_screen.mainloop()


Registrationform()
