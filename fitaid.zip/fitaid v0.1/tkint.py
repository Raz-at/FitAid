import tkinter as tk
import os

def button_callback(text):
    print(text)

root = tk.Tk()
root.title("FitAid")

def squat():
    os.system("python squats.py")
def pushup():
    os.system("python pushup.py")
def curl():
    os.system("python Curl.py")
def P_workout():
    os.system("python WorkOut.py")

Label1 = tk.Label(root , text=  "FitAid")
Label1.pack()

Label2 = tk.Label(root , text=  "Count your exercise")
Label2.pack()

button1 = tk.Button(root, text="Button 1", command=squat)
button1.pack(side="left", padx=10, pady=10 , expand=True)

button2 = tk.Button(root, text="Button 2", command=pushup)
button2.pack(side="left", padx=10, pady=10 , expand=True)

button3 = tk.Button(root, text="Button 3", command=curl)
button3.pack(side="left", padx=10, pady=10 , expand=True)

label3 = tk.Label(root , text="Create your personal Work out plan")
label3.pack(side="bottom" , padx=10, pady=10 , expand=True)

button4 = tk.Button(root, text="Button 3", command= P_workout)
button4.pack( padx=10, pady=10 , expand=True)

root.mainloop()
