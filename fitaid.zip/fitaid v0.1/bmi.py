import requests
import tkinter as tk
from PIL import ImageTk
import sqlite3
from numpy import random
import pyglet

input_age = names = open("C:/Users/Binit/Desktop/fitaid v0.1/age.txt", "r")
input_height = names = open("C:/Users/Binit/Desktop/fitaid v0.1/Height.txt", "r")
input_weight = names = open("C:/Users/Binit/Desktop/fitaid v0.1/weight.txt", "r")
height = input_height.read()
height = int(height)
height = height/100
sqheight = height * height
weight = input_weight.read()
weight = int(weight)
bmi = weight/sqheight
bmi = int(bmi)


# set colours
bg_colour = "#3d6466"

# load custom fonts
pyglet.font.add_file("fonts/Ubuntu-Bold.ttf")
pyglet.font.add_file("fonts/Shanti-Regular.ttf")


def clear_widgets(frame):
    # select all frame widgets and delete them
    for widget in frame.winfo_children():
        widget.destroy()


def load_frame1():
    clear_widgets(frame2)
    # stack frame 1 above frame 2
    frame1.tkraise()
    # prevent widgets from modifying the frame
    frame1.pack_propagate(False)

    # create logo widget
    logo_img = ImageTk.PhotoImage(file="logo.png")
    logo_widget = tk.Label(frame1, image=logo_img, bg=bg_colour)
    logo_widget.image = logo_img
    logo_widget.pack()

    tk.Label(
        frame1,
        text="Your bmi is :",
        bg="#28393a",
        fg="white",
        font=("Shanti", 12)
    ).pack(fill="both", padx=25)
    tk.Label(
        frame1,
        text=bmi,
        bg="#28393a",
        fg="white",
        font=("Shanti", 12)
    ).pack(fill="both", padx=25)

    tk.Label(
        frame1,
        text="Healthy bmi range is :",
        bg="#28393a",
        fg="white",
        font=("Shanti", 12)
    ).pack(fill="both", padx=25)
    tk.Label(
        frame1,
        text="18-25",
        bg="#28393a",
        fg="white",
        font=("Shanti", 12)
    ).pack(fill="both", padx=25)


# initiallize app with basic settings
root = tk.Tk()
root.title("Your BMI")
root.eval("tk::PlaceWindow . center")

# place app in the center of the screen (alternative approach to root.eval())
# x = root.winfo_screenwidth() // 2
# y = int(root.winfo_screenheight() * 0.1)
# root.geometry('500x600+' + str(x) + '+' + str(y))

# create a frame widgets
frame1 = tk.Frame(root, width=500, height=600, bg=bg_colour)
frame2 = tk.Frame(root, bg=bg_colour)

# place frame widgets in window
for frame in (frame1, frame2):
    frame.grid(row=0, column=0, sticky="nesw")

# load the first frame
load_frame1()

# run app
root.mainloop()
