import tkinter as tk
from PIL import ImageTk
from numpy import random
import pyglet
import os
from tkinter import filedialog


def upload():
    filename = filedialog.askopenfilename()
    print('Selected:', filename)
    names = open("C:/Users/Binit/Desktop/fitaid v0.1/pushupfile.txt", "w")
    names.write(filename)


def watch():
    os.system("python pushup.py")


def camera():
    os.system("python pushcamera.py")


# set colours
bg_colour = "#3d6466"

# load custom fonts
pyglet.font.add_file("fonts/Ubuntu-Bold.ttf")
pyglet.font.add_file("fonts/Shanti-Regular.ttf")


def clear_widgets(frame):
    # select all frame widgets and delete them
    for widget in frame.winfo_children():
        widget.destroy()


def load_frame1():
    clear_widgets(frame2)
    # stack frame 1 above frame 2
    frame1.tkraise()
    # prevent widgets from modifying the frame
    frame1.pack_propagate(False)

    # create logo widget
    logo_img = ImageTk.PhotoImage(file="logo.png")
    logo_widget = tk.Label(frame1, image=logo_img, bg=bg_colour)
    logo_widget.image = logo_img
    logo_widget.pack()

    tk.Label(
        frame1,
        text="Choose an operation",
        bg=bg_colour,
        fg="white",
        font=("Shanti", 14)
    ).pack()

    # create button widget
    tk.Button(
        frame1,
        text="Upload workout",
        font=("Ubuntu", 20),
        bg="#28393a",
        fg="white",
        cursor="hand2",
        activebackground="#badee2",
        activeforeground="black",
        command=lambda: upload()
    ).pack(pady=10)

    # create button widget
    tk.Button(
        frame1,
        text="View uploaded workout",
        font=("Ubuntu", 20),
        bg="#28393a",
        fg="white",
        cursor="hand2",
        activebackground="#badee2",
        activeforeground="black",
        command=lambda: watch()
    ).pack(pady=10)

    tk.Button(
        frame1,
        text="Record workout",
        font=("Ubuntu", 20),
        bg="#28393a",
        fg="white",
        cursor="hand2",
        activebackground="#badee2",
        activeforeground="black",
        command=lambda: camera()
    ).pack(pady=10)


# initiallize app with basic settings
root = tk.Tk()
root.title("Fitaid")
root.eval("tk::PlaceWindow . center")

# place app in the center of the screen (alternative approach to root.eval())
# x = root.winfo_screenwidth() // 2
# y = int(root.winfo_screenheight() * 0.1)
# root.geometry('500x600+' + str(x) + '+' + str(y))

# create a frame widgets
frame1 = tk.Frame(root, width=500, height=600, bg=bg_colour)
frame2 = tk.Frame(root, bg=bg_colour)

# place frame widgets in window
for frame in (frame1, frame2):
    frame.grid(row=0, column=0, sticky="nesw")

# load the first frame
load_frame1()

# run app
root.mainloop()
