import tkinter as tk
from PIL import ImageTk
import os
from numpy import random
import pyglet

# set colours
bg_colour = "#3d6466"

# load custom fonts
pyglet.font.add_file("fonts/Ubuntu-Bold.ttf")
pyglet.font.add_file("fonts/Shanti-Regular.ttf")

# names = open("C:/Bhai/project/fitaid/name.txt", "r")
names = open("C:/Users/Binit/Desktop/fitaid v0.1/name.txt", "r")
name = names.read()


def workout():
    os.system("python exercise.py")


def recipe():
    os.system("python recipePicker.py")


def personal():
    os.system("python personal.py")


def P_workout():
    os.system("python Pyfit.py")


def bmi():
    os.system("python bmi.py")


def clear_widgets(frame):
    # select all frame widgets and delete them
    for widget in frame.winfo_children():
        widget.destroy()


def load_frame1():
    clear_widgets(frame2)
    # stack frame 1 above frame 2
    frame1.tkraise()
    # prevent widgets from modifying the frame
    frame1.pack_propagate(False)

    # create logo widget
    logo_img = ImageTk.PhotoImage(file="logo.png")
    logo_widget = tk.Label(frame1, image=logo_img, bg=bg_colour)
    logo_widget.image = logo_img
    logo_widget.pack()

    # create label widget for instructions
    tk.Label(
        frame1,
        text=name + ", Choose an operation",
        bg=bg_colour,
        fg="white",
        font=("Shanti", 14)
    ).pack()

    # create button widget
    tk.Button(
        frame1,
        text="Workout",
        font=("Ubuntu", 20),
        bg="#28393a",
        fg="white",
        cursor="hand2",
        activebackground="#badee2",
        activeforeground="black",
        command=lambda: workout()
    ).pack(pady=7)

    # create button widget
    tk.Button(
        frame1,
        text="Personal Plan",
        font=("Ubuntu", 20),
        bg="#28393a",
        fg="white",
        cursor="hand2",
        activebackground="#badee2",
        activeforeground="black",
        command=lambda: P_workout()
    ).pack(pady=7)

    tk.Button(
        frame1,
        text="Update your details",
        font=("Ubuntu", 20),
        bg="#28393a",
        fg="white",
        cursor="hand2",
        activebackground="#badee2",
        activeforeground="black",
        command=lambda: personal()
    ).pack(pady=7)

    tk.Button(
        frame1,
        text="Your bmi",
        font=("Ubuntu", 20),
        bg="#28393a",
        fg="white",
        cursor="hand2",
        activebackground="#badee2",
        activeforeground="black",
        command=lambda: bmi()
    ).pack(pady=7)

    tk.Button(
        frame1,
        text="Healthy recipe",
        font=("Ubuntu", 20),
        bg="#28393a",
        fg="white",
        cursor="hand2",
        activebackground="#badee2",
        activeforeground="black",
        command=lambda: recipe()
    ).pack(pady=7)


# initiallize app with basic settings
root = tk.Tk()
root.title("Fitaid")
root.eval("tk::PlaceWindow . center")

# place app in the center of the screen (alternative approach to root.eval())
# x = root.winfo_screenwidth() // 2
# y = int(root.winfo_screenheight() * 0.1)
# root.geometry('500x600+' + str(x) + '+' + str(y))

# create a frame widgets
frame1 = tk.Frame(root, width=500, height=600, bg=bg_colour)
frame2 = tk.Frame(root, bg=bg_colour)

# place frame widgets in window
for frame in (frame1, frame2):
    frame.grid(row=0, column=0, sticky="nesw")

# load the first frame
load_frame1()

# run app
root.mainloop()
