import numpy as np
import cv2 as cv
import mediapipe as mp
import poseEstimationModule as pem

names = open("C:/Users/Binit/Desktop/fitaid v0.1/curlfile.txt", "r")
name = names.read()

cap = cv.VideoCapture(name)
detector = pem.poseEstimation()

dir = 0
count = 0


while True:
    isTrue, img = cap.read()
    img = cv.resize(img, (500, 600))
    img = detector.findPose(img, False)
    lmlist = detector.getPosition(img, False)
    # print(lmlist)
    if len(lmlist) != 0:
        # LEFT
        angle = detector.Curlangle(img, 11, 13, 15)

        per = np.interp(angle, (40, 110), (0, 100))
        bar = np.interp(angle, (40, 100), (250, 100))

        print(angle, per)
        # # RIGHT
        # detector.angle(img , 12, 14 ,16)

        if per == 100:
            if dir == 0:
                count += 0.5
                dir = 1
        if per == 0:
            if dir == 1:
                count += 0.5
                dir = 0
        print(count)

        cv.rectangle(img, (20, 100), (40, 250), (255, 0, 0), 2)
        cv.rectangle(img, (20, int(bar)), (40, 250), (255, 0, 255), cv.FILLED)
        cv.putText(img, f'{int(per)}%', (20, 80),
                   cv.FONT_HERSHEY_PLAIN, 1, (0, 0, 0), 1)

        cv.putText(img, "Count:", (5, 550),
                   cv.FONT_HERSHEY_PLAIN, 2, (255, 255, 0), 3)
        # cv.rectangle(img , (0 , 500), (100, 600) , (255 , 0 , 255 ),cv.FILLED)
        cv.putText(img, str(count), (115, 550),
                   cv.FONT_HERSHEY_PLAIN, 2, (255, 255, 0), 3)

    cv.imshow("pose", img)
    if cv.waitKey(1) & 0xFF == ord("a"):
        break

cap.release()
cv.destroyAllWindows()
