import cv2 as cv
import mediapipe as mp
import time
import math

class poseEstimation():
    def __init__(self , static=False, mode=False , upBody=False , smooth=True , detectionCon = 0.1 , trackCon= 0.1 ):
        self.static = static
        self.mode = mode
        self.upBody = upBody
        self.smooth = smooth
        self.detectionCon = detectionCon
        self.trackCon = trackCon
        self.mpPose = mp.solutions.pose
        self.pose = self.mpPose.Pose(self.static , self.mode , self.upBody , self.smooth , self.detectionCon , self.trackCon)
        self.mpDraw = mp.solutions.drawing_utils

    def findPose(self , img ,draw=True):
        imgRBG = cv.cvtColor(img , cv.COLOR_RGB2BGR)
        self.result = self.pose.process(imgRBG)
        # print(result.pose_landmarks)
        if self.result.pose_landmarks:
            if draw:
                self.mpDraw.draw_landmarks(img, self.result.pose_landmarks , self.mpPose.POSE_CONNECTIONS)
        return img

    def getPosition(self , img , draw =True  ):
        self.lmlist = []
        if self.result.pose_landmarks:
            for id , lm in enumerate(self.result.pose_landmarks.landmark):
                h ,w, c = img.shape
                cx , cy =int(lm.x*w) , int(lm.y*h)
                self.lmlist.append([id , cx , cy])
                # if draw:
                #     if id == 14:
                #         cv.circle(img , (cx, cy) , 5 , (255,0,255) , 3 , cv.FILLED)
        return self.lmlist 


######Curl##
    def Curlangle(self , img ,p1 , p2 , p3 , draw=True):
        x1 , y1 = self.lmlist[p1][1:]
        x2 , y2 = self.lmlist[p2][1:]
        x3 , y3 = self.lmlist[p3][1:]

        Curlangle = math.degrees(math.atan2( y3-y2 , x3-x2) - math.atan2 (y2-y1 , x2-x1))
        
        if Curlangle <= 0:
            Curlangle+=360

        if draw:
            cv.line(img , (x1,y1) , (x2,y2) , (255 , 255 , 255) , 2)
            cv.line(img , (x2,y2) , (x3,y3) , (255 , 255 , 255)  , 2)
            cv.circle(img , (x1, y1) , 5 , (255,0,255) ,  cv.FILLED)
            cv.circle(img , (x1, y1) , 15 , (255,0,255) , 3 )
            cv.circle(img , (x2, y2) , 5 , (255,0,255) ,  cv.FILLED)
            cv.circle(img , (x2, y2) , 15 , (255,0,255) , 3 )
            cv.circle(img , (x3, y3) , 5 , (255,0,255) ,  cv.FILLED)
            cv.circle(img , (x3, y3) , 15 , (255,0,255) , 3 )
            cv.putText(img , str(int(Curlangle)) , (x2+10 , y2+50) , cv.FONT_HERSHEY_PLAIN , 2, (0,0,0) , 2)

        return Curlangle
##curl####  
      
###Pushup###
    def PushUpangle(self , img , p1 , p2 , p3, p4 , p5 , p6 , draw=True):
        x1 , y1 = self.lmlist[p1][1:]
        x2 , y2 = self.lmlist[p2][1:]
        x3 , y3 = self.lmlist[p3][1:]
        x4 , y4 = self.lmlist[p4][1:]
        x5 , y5 = self.lmlist[p5][1:]
        x6 , y6 = self.lmlist[p6][1:]
        PushUpangle = math.degrees(math.atan2( y3-y2 , x3-x2) - math.atan2 (y2-y1 , x2-x1))

        if PushUpangle<0:
            PushUpangle +=360

        # sideangle = math.degrees(math.atan2(y5-y4 , x5-x4)-math.atan2(y4-y3,x4-x3))
        # if sideangle<0:
            # sideangle +=360
        if draw:
            cv.line(img , (x1,y1) , (x2,y2) , (255 , 255 , 255) , 2)
            cv.line(img , (x2,y2) , (x3,y3) , (255 , 255 , 255) , 2)
            cv.line(img , (x3,y3) , (x4,y4) , (255 , 255 , 255) , 2)
            cv.line(img , (x4,y4) , (x5,y5) , (255 , 255 , 255) , 2)
            cv.line(img , (x5,y5) , (x6,y6) , (255 , 255 , 255) , 2)
            cv.circle(img , (x1, y1) , 5 , (255,0,255) ,  cv.FILLED)
            cv.circle(img , (x1, y1) , 15 , (255,0,255) , 3 )
            cv.circle(img , (x2, y2) , 5 , (255,0,255) ,  cv.FILLED)
            cv.circle(img , (x2, y2) , 15 , (255,0,255) , 3 )
            cv.circle(img , (x3, y3) , 5 , (255,0,255) ,  cv.FILLED)
            cv.circle(img , (x3, y3) , 15 , (255,0,255) , 3 )
            cv.circle(img , (x4, y4) , 5 , (255,0,255) ,  cv.FILLED)
            cv.circle(img , (x4, y4) , 15 , (255,0,255) , 3 )
            cv.circle(img , (x5, y5) , 5 , (255,0,255) ,  cv.FILLED)
            cv.circle(img , (x5, y5) , 15 , (255,0,255) , 3 )
            cv.circle(img , (x6, y6) , 5 , (255,0,255) ,  cv.FILLED)
            cv.circle(img , (x6, y6) , 15 , (255,0,255) , 3 )
            cv.putText(img , str(int(PushUpangle)) , (x2+10 , y2+50) , cv.FONT_HERSHEY_PLAIN , 2, (0,0,0) , 2)
            # cv.putText(img , str(int(sideangle)) , (x4+10 , y4+50) , cv.FONT_HERSHEY_PLAIN , 2, (0,0,0) , 2)
        return PushUpangle

###PushUp###



###squat####
    def Squatangle(self , img , p1 , p2 , p3 , p4, p5 ,p6 , draw=True):
        x1 , y1 =self.lmlist[p1][1:]
        x2 , y2 =self.lmlist[p2][1:]
        x3 , y3 =self.lmlist[p3][1:]
        x4 , y4 =self.lmlist[p4][1:]
        x5 , y5 =self.lmlist[p5][1:]
        x6 , y6 =self.lmlist[p6][1:]
        Squatangle = math.degrees(math.atan2(y6 - y5 , x6-x5)-math.atan2(y5-y4 , x5-x4))
        if Squatangle<0:
            Squatangle +=360

            cv.line(img , (x1 , y1) , (x2 , y2) , (255 , 255 , 255) , 1)
            cv.line(img , (x2 , y2) , (x3 , y3) , (255 , 255 , 255) , 1)
            cv.line(img , (x3 , y3) , (x4 , y4) , (255 , 255 , 255) , 1)
            cv.line(img , (x4 , y4) , (x5 , y5) , (255 , 255 , 255) , 1)
            cv.line(img , (x5 , y5) , (x6 , y6) , (255 , 255 , 255) , 1)
            cv.circle(img , (x1, y1) , 5 , (255,0,255) ,  cv.FILLED)
            cv.circle(img , (x1, y1) , 10 , (255,0,255) , 3 )
            cv.circle(img , (x2, y2) , 5 , (255,0,255) ,  cv.FILLED)
            cv.circle(img , (x2, y2) , 10 , (255,0,255) , 3 )
            cv.circle(img , (x3, y3) , 5 , (255,0,255) ,  cv.FILLED)
            cv.circle(img , (x3, y3) , 10 , (255,0,255) , 3 )
            cv.circle(img , (x4, y4) , 5 , (255,0,255) ,  cv.FILLED)
            cv.circle(img , (x4, y4) , 10 , (255,0,255) , 3 )
            cv.circle(img , (x5, y5) , 5 , (255,0,255) ,  cv.FILLED)
            cv.circle(img , (x5, y5) , 10 , (255,0,255) , 3 )
            cv.circle(img , (x6, y6) , 5 , (255,0,255) ,  cv.FILLED)
            cv.circle(img , (x6, y6) , 10 , (255,0,255) , 3 )
            cv.putText(img , str(int(Squatangle)) ,(x5+10 , y5+50) , cv.FONT_HERSHEY_PLAIN , 2, (0,0,0) , 2 )


        return Squatangle 




###squat####





            


