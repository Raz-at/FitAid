from tkinter import *
# import squats
import os

root = Tk()
width = 450
height = 400

width_screen = root.winfo_screenwidth()
height_screen = root.winfo_screenheight()

spawn_x = int((width_screen / 2) - (width / 2))
spawn_y = int((height_screen / 2) - (height / 2))

root.geometry(f"{width}x{height}+{spawn_x}+{spawn_y}")
root.title("FitAid")
# root.config(bg='black')


def squat():
    os.system("python squats.py")


def pushup():
    os.system("python pushup.py")


def curl():
    os.system("python Curl.py")


def P_workout():
    os.system("python WorkOut.py")


def bmi():
    os.system("python bmi.py")


def exit_window():
    buttomframe.destroy()
    exit()


label1 = Label(root, text="FitAid", font=100,
               padx=20, pady=10, foreground='#8B0000')
label1.pack()

label2 = Label(root, text="Count your workout", font=100,
               padx=20, pady=10, foreground='#8B0000')
label2.pack()

buttomframe = Frame(root)
buttomframe.columnconfigure(0, weight=1)
buttomframe.columnconfigure(1, weight=1)
buttomframe.columnconfigure(2, weight=1)

button1 = Button(buttomframe, text="Squat", padx=20, pady=10, command=squat)
button1.grid(row=2, column=0, sticky=W+E)
button2 = Button(buttomframe, text="Push Up", padx=20, pady=10, command=pushup)
button2.grid(row=2, column=1, sticky=W+E)
button3 = Button(buttomframe, text="Bicep Curl",
                 padx=20, pady=10, command=curl)
button3.grid(row=2, column=2, sticky=W+E)

label3 = Label(buttomframe, text="Count your workout", padx=30,
               pady=30,  foreground='#8B0000', font=100)
label3.grid(row=3, column=1)

button3 = Button(buttomframe, text="Personal Workout",
                 padx=20, pady=10, command=P_workout)
button3.grid(row=4, column=1, sticky=W+E)

button3 = Button(buttomframe, text="See your current bmi",
                 padx=20, pady=10, command=bmi)
button3.grid(row=4, column=2, sticky=W+E)

Button(buttomframe, text="Exit", command=exit_window).grid(row=8, sticky=W)


buttomframe.pack(fill='x')
root.mainloop()

# if __name__ == "__main__":
#     clickme()
