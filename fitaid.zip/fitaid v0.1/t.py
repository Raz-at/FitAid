import requests
import tkinter as tk
from PIL import ImageTk
import sqlite3
from numpy import random
import pyglet

input_age = open("F:/Bhai/project/fitaid/age.txt", "r")
input_height = open("F:/Bhai/project/fitaid/height.txt", "r")
input_weight = open("F:/Bhai/project/fitaid/weight.txt", "r")

url = "https://fitness-calculator.p.rapidapi.com/bmi"

querystring = {"age": input_age.read(), "height": input_height.read(),
               "weight": input_weight.read(), }

headers = {
    "X-RapidAPI-Key": "ba2723de62mshc3a952864721933p12f085jsnfd971e3f37a4",
    "X-RapidAPI-Host": "fitness-calculator.p.rapidapi.com"
}

response = requests.request("GET", url, headers=headers, params=querystring)
macros = response.json()
print(response.text)


# set colours
bg_colour = "#3d6466"

# load custom fonts
pyglet.font.add_file("fonts/Ubuntu-Bold.ttf")
pyglet.font.add_file("fonts/Shanti-Regular.ttf")


def clear_widgets(frame):
    # select all frame widgets and delete them
    for widget in frame.winfo_children():
        widget.destroy()


def load_frame1():
    clear_widgets(frame2)
    # stack frame 1 above frame 2
    frame1.tkraise()
    # prevent widgets from modifying the frame
    frame1.pack_propagate(False)

    # create logo widget
    logo_img = ImageTk.PhotoImage(file="logo.png")
    logo_widget = tk.Label(frame1, image=logo_img, bg=bg_colour)
    logo_widget.image = logo_img
    logo_widget.pack()

    tk.Label(
        frame1,
        text=querystring['age'] + ' ' +
        querystring['weight'] + ' ' + querystring['height'],
        bg=bg_colour,
        fg="white",
        font=("Ubuntu", 20)
    ).pack(pady=25, padx=25)

    for i in macros['data']:
        tk.Label(
            frame1,
            text="Your " + i + " is :",
            bg="#28393a",
            fg="white",
            font=("Shanti", 12)
        ).pack(fill="both", padx=25)
        tk.Label(
            frame1,
            text=macros['data'][i],
            bg="#28393a",
            fg="white",
            font=("Shanti", 12)
        ).pack(fill="both", padx=25)


# initiallize app with basic settings
root = tk.Tk()
root.title("Your BMI")
root.eval("tk::PlaceWindow . center")

# place app in the center of the screen (alternative approach to root.eval())
# x = root.winfo_screenwidth() // 2
# y = int(root.winfo_screenheight() * 0.1)
# root.geometry('500x600+' + str(x) + '+' + str(y))

# create a frame widgets
frame1 = tk.Frame(root, width=500, height=600, bg=bg_colour)
frame2 = tk.Frame(root, bg=bg_colour)

# place frame widgets in window
for frame in (frame1, frame2):
    frame.grid(row=0, column=0, sticky="nesw")

# load the first frame
load_frame1()

# run app
root.mainloop()
