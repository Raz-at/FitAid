import numpy as np
import cv2 as cv
import mediapipe as mp
import poseEstimationModule as pem

names = open("C:/Users/Binit/Desktop/fitaid v0.1/pushupfile.txt", "r")
name = names.read()

cap = cv.VideoCapture(name)
detector = pem.poseEstimation()

dir = 0
count = 0

while True:
    isTrue, img = cap.read()
    img = cv.resize(img, (1280, 600))
    img = detector.findPose(img, False)

    lmlist = detector.getPosition(img, False)

    if len(lmlist) != 0:
        angle = detector.PushUpangle(img, 15, 13, 11, 23, 25, 27)
        print(angle)
        per = np.interp(angle, (245, 330), (0, 100))
        bar = np.interp(angle, (245, 330), (250, 100))

    if per == 100:
        if dir == 0:
            count += 0.5
            dir = 1
    if per == 0:
        if dir == 1:
            count += 0.5
            dir = 0
    print(count)

    cv.rectangle(img, (20, 100), (40, 250), (0, 0, 0), 1)
    cv.rectangle(img, (20, int(bar)), (40, 250), (255, 0, 0), cv.FILLED)
    cv.putText(img, f'{int(per)}%', (20, 80),
               cv.FONT_HERSHEY_PLAIN, 1, (0, 0, 0), 1)

    cv.putText(img, "Count:", (5, 550),
               cv.FONT_HERSHEY_PLAIN, 2, (255, 255, 0), 3)
    cv.putText(img, str(count), (115, 550),
               cv.FONT_HERSHEY_PLAIN, 2, (255, 255, 0), 3)

    cv.imshow("video", img)
    if cv.waitKey(1) & 0xff == ord('a'):
        break


cap.release()
cv.destroyAllWindows()
